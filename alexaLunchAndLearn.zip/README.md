# alexaLunchAndLearn

```
npm install
```
# index.js

This file is provided as the entry point (be default) of an AWS lambda function.  It contains all the handler logic and utilizes the Alexa Skills sdk avaialable via npm.

# lunchbot.js

This file is the main entry point for a bot to access slack.  If you're looking to do a slack integration, I recommend checking out the slack documentation directly. (https://api.slack.com/)  There is also an npm package utilized here.
